This is practice for setting up a python package pypi
